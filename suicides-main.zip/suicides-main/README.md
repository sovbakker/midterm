# suicides
# https://share.streamlit.io/sovbakoid/suicides/main/project13.py
